export default async function handler(req, res) {
  const { query } = req.query;

  const mockData = [
    { id: 1, title: "Yargıtay 2024/1234 Kararı", summary: "İçtihat özeti 1" },
    { id: 2, title: "Danıştay 2023/5678 Kararı", summary: "İçtihat özeti 2" },
  ];

  const filteredResults = mockData.filter((item) =>
    item.title.toLowerCase().includes(query.toLowerCase())
  );

  res.status(200).json(filteredResults);
}
