import Link from "next/link";
import Navbar from "../components/Navbar";

export default function Home() {
  return (
    <div style={{ textAlign: "center", padding: "50px" }}>
      <Navbar />
      <h1>Adalex - Yapay Zeka Destekli İçtihat Arama</h1>
      <p>Hızlı ve akıllı içtihat sorgulama</p>
      <Link href="/search">
        <button style={{ padding: "10px 20px", fontSize: "18px" }}>Arama Yap</button>
      </Link>
    </div>
  );
}
