import { useRouter } from "next/router";
import Navbar from "../../components/Navbar";

export default function CaseDetail() {
  const router = useRouter();
  const { id } = router.query;

  return (
    <div style={{ textAlign: "center", padding: "50px" }}>
      <Navbar />
      <h1>İçtihat Detayı (ID: {id})</h1>
      <p>Bu bölümde içtihat detayları gösterilecek.</p>
    </div>
  );
}
