import { useState } from "react";
import Navbar from "../components/Navbar";

export default function Search() {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);

  const searchCases = async () => {
    const response = await fetch(`/api/search?query=${query}`);
    const data = await response.json();
    setResults(data);
  };

  return (
    <div style={{ textAlign: "center", padding: "50px" }}>
      <Navbar />
      <h1>İçtihat Arama</h1>
      <input 
        type="text" 
        value={query} 
        onChange={(e) => setQuery(e.target.value)} 
        placeholder="Anahtar kelime giriniz..."
      />
      <button onClick={searchCases}>Ara</button>

      <ul>
        {results.map((caseData) => (
          <li key={caseData.id}>
            <a href={`/case/${caseData.id}`}>{caseData.title}</a>
          </li>
        ))}
      </ul>
    </div>
  );
}
