import Link from "next/link";

export default function Navbar() {
  return (
    <nav style={{ padding: "10px", background: "#222", color: "#fff", textAlign: "center" }}>
      <Link href="/">Ana Sayfa</Link> | <Link href="/search">İçtihat Ara</Link>
    </nav>
  );
}
