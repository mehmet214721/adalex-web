# Adalex Web
Bu proje, Adalex'in Next.js tabanlı web sürümüdür.

## Kurulum
1. **Bağımlılıkları yükleyin:**  
   ```sh
   npm install
   ```

2. **Geliştirme ortamını başlatın:**  
   ```sh
   npm run dev
   ```

3. **Tarayıcıda açın:**  
   - `http://localhost:3000`
